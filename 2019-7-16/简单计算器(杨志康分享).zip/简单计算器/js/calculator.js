(function() {

  //获取元素方法
  var el = function(element) {
    //charAt() 方法用于返回指定索引处的字符。索引范围为从 0 到 length - 1。
    if (element.charAt(0) === "#") { 
      //可以获取有id元素
      return document.querySelector(element); 
    }
    return document.querySelectorAll(element);
  };

  //调用获取元素方法，获取元素
  var viewer = el("#viewer"), //显示计算结果的元素
    equals = el("#equals"), //等于按钮
    nums = el(".num"), // 获取数字0~9和小数点
    ops = el(".ops"), // 获取运算符号（加减乘除）
    theNum = "", // 当前数
    oldNum = "", // 上一个数
    endNum, //计算结果数变量
    operator; //运算符号变量

  // 当单击数字0~9和小数点,获取选定的当前值
  var setNum = function() {
    if (endNum) { // 如果显示结果，则重置编号
      theNum = this.getAttribute("data-num");
      endNum = "";
    } else { // 否则，将数字添加到前面的数字(这是一个字符串!)
      theNum += this.getAttribute("data-num");
    }
    viewer.innerHTML = theNum; // 显示当前数量
  };

  //单击操作符，将当前数变为上一个数并保存，新的数为空
  var moveNum = function() {
    oldNum = theNum;
    theNum = "";
    //给操作符赋值(加上，减去，乘以，除以)
    operator = this.getAttribute("data-ops");
    equals.setAttribute("data-result", ""); // 重置结果在attr
  };

  // 当等于号被点击，计算结果
  var displayNum = function() {
    //将字符串输入转换为数字
    oldNum = parseFloat(oldNum);
    theNum = parseFloat(theNum);

    //循坏判断传进来的运算符号，并进行相应的计算
    switch (operator) {
      case "加上":
        endNum = oldNum + theNum;
        break;

      case "减去":
        endNum = oldNum - theNum;
        break;

      case "乘以":
        endNum = oldNum * theNum;
        break;

      case "除以":
        endNum = oldNum / theNum;
        break;
        // 如果在没有操作符的情况下按下等于号，保留number并继续
      default:
        endNum = theNum;
    }

    //如果返回NaN或无穷大
    if (!isFinite(endNum)) {
      //isFinite() 函数用于检查其参数是否是无穷大。
      //如果 number 是 NaN（非数字），或者是正、负无穷大的数，则返回 false。
      if (isNaN(endNum)) {//如果结果不是一个数字;
        endNum = "输入正确的数字!";
      } else { //如果结果是无穷大，就除以零
        endNum = "看看你都做了些什么";
        el('#calculator').classList.add("broken"); // 打破计算器可计算范围
      }
    }

    // 最终显示结果
    viewer.innerHTML = endNum;
    equals.setAttribute("data-result", endNum);

    //现在重置上个数字并保存结果
    oldNum = 0;
    theNum = endNum;

  };

  //按下清除按钮，清零
  var clearAll = function() {
    oldNum = "";
    theNum = "";
    viewer.innerHTML = "0";
    equals.setAttribute("data-result", endNum);
  };

  /* 元素单击事件 */

  // 向数字和小数点添加单击事件
  for (var i = 0, l = nums.length; i < l; i++) {
    nums[i].onclick = setNum;
  }

  // 向操作符添加单击事件
  for (var i = 0, l = ops.length; i < l; i++) {
    ops[i].onclick = moveNum;
  }

  // 等号添加单击事件
  equals.onclick = displayNum;

  // 清除按钮添加单击事件
  el("#clear").onclick = clearAll;

  // 重置按钮添加单击事件
  el("#reset").onclick = function() {
    window.location = window.location;
  };

}());